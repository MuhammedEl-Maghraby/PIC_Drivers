/* 
 * File:   compiler.h
 * Author: Maghraby
 *
 * Created on February 26, 2022, 3:47 PM
 */

#ifndef COMPILER_H
#define	COMPILER_H
/* Section: Includes*/

#include <xc.h>



/*Section: Macro Definitions*/


/*Section: Function Like Macros*/


/*Section: Data Type Declaration*/



/*Section: Function Prototypes*/




#endif	/* COMPILER_H */

