/* 
 * File:   std_libraries.h
 * Author: Maghraby
 *
 * Created on February 26, 2022, 3:46 PM
 */

#ifndef STD_LIBRARIES_H
#define	STD_LIBRARIES_H


/* Section: Includes*/

#include <stdio.h>
#include <stdlib.h>



/*Section: Macro Definitions*/


/*Section: Function Like Macros*/


/*Section: Data Type Declaration*/



/*Section: Function Prototypes*/



#endif	/* STD_LIBRARIES_H */

