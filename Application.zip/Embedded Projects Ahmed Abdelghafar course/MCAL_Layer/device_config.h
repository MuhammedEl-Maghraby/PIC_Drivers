/* 
 * File:   device_config.h
 * Author: Maghraby
 *
 * Created on February 26, 2022, 4:07 PM
 */

#ifndef DEVICE_CONFIG_H
#define	DEVICE_CONFIG_H

/* Section: Includes*/


/*Section: Macro Definitions*/


/*Section: Function Like Macros*/


/*Section: Data Type Declaration*/



/*Section: Function Prototypes*/




#endif	/* DEVICE_CONFIG_H */

