/* 
 * File:   ecu_button_cfg.h
 * Author: Maghraby
 *
 * Created on March 18, 2022, 2:16 PM
 */

#ifndef ECU_BUTTON_CFG_H
#define	ECU_BUTTON_CFG_H

/* Section: Includes*/





/*Section: Macro Definitions*/


/*Section: Function Like Macros*/


/*Section: Data Type Declaration*/



/*Section: Function Prototypes*/


#endif	/* ECU_BUTTON_CFG_H */

