/* 
 * File:   ecu_relay_cfg.h
 * Author: Maghraby
 *
 * Created on March 20, 2022, 8:41 PM
 */

#ifndef ECU_RELAY_CFG_H
#define	ECU_RELAY_CFG_H

/* Section: Includes*/


/*Section: Macro Definitions*/


/*Section: Function Like Macros*/


/*Section: Data Type Declaration*/



/*Section: Function Prototypes*/



#endif	/* ECU_RELAY_CFG_H */

