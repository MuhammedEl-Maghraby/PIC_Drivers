/* 
 * File:   ecu_led_config.h
 * Author: Maghraby
 *
 * Created on March 15, 2022, 6:40 PM
 */

#ifndef ECU_LED_CONFIG_H
#define	ECU_LED_CONFIG_H

/* Section: Includes*/





/*Section: Macro Definitions*/


/*Section: Function Like Macros*/


/*Section: Data Type Declaration*/



/*Section: Function Prototypes*/


#endif	/* ECU_LED_CONFIG_H */

