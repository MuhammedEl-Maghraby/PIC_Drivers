/* 
 * File:   ecu_dc_motor_cfg.h
 * Author: Maghraby
 *
 * Created on March 22, 2022, 3:30 PM
 */

#ifndef ECU_DC_MOTOR_CFG_H
#define	ECU_DC_MOTOR_CFG_H


/* Section: Includes*/

/*Section: Macro Definitions*/


/*Section: Function Like Macros*/


/*Section: Data Type Declaration*/


/*Section: Function Prototypes*/


#endif	/* ECU_DC_MOTOR_CFG_H */

