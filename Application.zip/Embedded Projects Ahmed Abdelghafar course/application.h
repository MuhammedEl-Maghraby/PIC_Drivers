/* 
 * File:   application.h
 * Author: Maghraby
 *
 * Created on February 26, 2022, 3:59 PM
 */

#ifndef APPLICATION_H
#define	APPLICATION_H

/* Section: Includes*/

#include "ECU_Layer/button/ecu_button.h"
#include "ECU_Layer/LED/ecu_led.h"
#include "ECU_Layer/DC_Motor/ecu_dc_motor.h"



/*Section: Macro Definitions*/


/*Section: Function Like Macros*/


/*Section: Data Type Declaration*/



/*Section: Function Prototypes*/

void application_initialize(void);




#endif	/* APPLICATION_H */

