/* 
 * File:   application.c
 * Author: Maghraby
 *
 * Created on February 26, 2022, 2:43 PM
 */



#include "application.h"


#define _XTAL_FREQ 4000000

/*
dc_motor_t motor_1 = {
    .motor_status = MOTOR_OFF_STATUS,
    .motor[0].motor_pin.port = PORTC_INDEX,
    .motor[0].motor_pin.pin = PIN0,
    .motor[0].motor_pin.direction = OUTPUT,
    .motor[0].motor_pin.logic = LOW,
    
    .motor[1].motor_pin.port = PORTC_INDEX,
    .motor[1].motor_pin.pin = PIN1,
    .motor[1].motor_pin.direction = OUTPUT,
    .motor[1].motor_pin.logic = LOW,
    
};

dc_motor_t motor_2 = {
    .motor_status = MOTOR_OFF_STATUS,
    .motor[0].motor_pin.port = PORTC_INDEX,
    .motor[0].motor_pin.pin = PIN3,
    .motor[0].motor_pin.direction = OUTPUT,
    .motor[0].motor_pin.logic = LOW,
    
    .motor[1].motor_pin.port = PORTC_INDEX,
    .motor[1].motor_pin.pin = PIN4,
    .motor[1].motor_pin.direction = OUTPUT,
    .motor[1].motor_pin.logic = LOW,
    
    
};
*/

Pin_Config_t pin1={
  .direction = OUTPUT,
  .port = PORTC_INDEX,
  .pin = PIN0,
  .logic = HIGH
};
int main(void) {  
    STD_ReturnType ret = E_NOT_OK;
    
    ret=gpio_pin_direction_initialize(&pin1);
    application_initialize();
    
    while(1){


        
        
        
        
    }
    return (EXIT_SUCCESS);
}

void application_initialize(void){
    STD_ReturnType ret = E_NOT_OK;

}
